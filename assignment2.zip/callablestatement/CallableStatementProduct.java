package com.jdbc.callablestatement;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.Scanner;

public class CallableStatementProduct {

	static final String URL = "jdbc:mysql://localhost:3306/inventorydb";
	static final String USER = "root";
	static final String PASSWORD = "root";

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		try {

			Class.forName("com.mysql.cj.jdbc.Driver");

			Connection con = DriverManager.getConnection(URL, USER, PASSWORD);

			System.out.print("Enter Category: ");
			String category = sc.nextLine();

			CallableStatement cs = con.prepareCall("{call GetProductsByCategory(?)}");

			cs.setString(1, category);

			ResultSet rs = cs.executeQuery();

			System.out.println("\nMatching Products");
			System.out.println("--------------------------------------------");

			while (rs.next()) {

				System.out.println(rs.getInt("product_id") + "\t" + rs.getString("product_name") + "\t"
						+ rs.getString("category") + "\t" + rs.getInt("quantity") + "\t" + rs.getDouble("price"));
			}

			rs.close();
			cs.close();
			con.close();
			sc.close();

		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
