package com.jdbc.preparedstatement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class PreparedStatementLibrary {
	public void insertBook(Connection con, Scanner sc) {

		try {
			String sql = "INSERT INTO books(book_id,title,author,category,price) VALUES(?,?,?,?,?)";

			PreparedStatement ps = con.prepareStatement(sql);

			System.out.print("Enter Book ID: ");
			ps.setInt(1, sc.nextInt());
			sc.nextLine();

			System.out.print("Enter Title: ");
			ps.setString(2, sc.nextLine());

			System.out.print("Enter Author: ");
			ps.setString(3, sc.nextLine());

			System.out.print("Enter Category: ");
			ps.setString(4, sc.nextLine());

			System.out.print("Enter Price: ");
			ps.setDouble(5, sc.nextDouble());

			int rows = ps.executeUpdate();

			if (rows > 0)
				System.out.println("Book Inserted Successfully!");

			ps.close();

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	// Update Price
	public void updatePrice(Connection con, Scanner sc) {

		try {
			String sql = "UPDATE books SET price=? WHERE book_id=?";

			PreparedStatement ps = con.prepareStatement(sql);

			System.out.print("Enter Book ID: ");
			int id = sc.nextInt();

			System.out.print("Enter New Price: ");
			double price = sc.nextDouble();

			ps.setDouble(1, price);
			ps.setInt(2, id);

			int rows = ps.executeUpdate();

			if (rows > 0)
				System.out.println("Price Updated Successfully!");
			else
				System.out.println("Book Not Found!");

			ps.close();

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	// Delete Book
	public void deleteBook(Connection con, Scanner sc) {

		try {
			String sql = "DELETE FROM books WHERE book_id=?";

			PreparedStatement ps = con.prepareStatement(sql);

			System.out.print("Enter Book ID: ");
			int id = sc.nextInt();

			ps.setInt(1, id);

			int rows = ps.executeUpdate();

			if (rows > 0)
				System.out.println("Book Deleted Successfully!");
			else
				System.out.println("Book Not Found!");

			ps.close();

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	// Display Books By Category
	public void displayBooks(Connection con, Scanner sc) {

		try {
			sc.nextLine();

			String sql = "SELECT * FROM books WHERE category=?";

			PreparedStatement ps = con.prepareStatement(sql);

			System.out.print("Enter Category: ");
			String category = sc.nextLine();

			ps.setString(1, category);

			ResultSet rs = ps.executeQuery();

			System.out.println("\nBook Details");
			System.out.println("---------------------------------------------");

			while (rs.next()) {
				System.out.println(rs.getInt("book_id") + "  " + rs.getString("title") + "  " + rs.getString("author")
						+ "  " + rs.getString("category") + "  " + rs.getDouble("price"));
			}

			rs.close();
			ps.close();

		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
