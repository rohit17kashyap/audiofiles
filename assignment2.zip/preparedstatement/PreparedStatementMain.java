package com.jdbc.preparedstatement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Scanner;

public class PreparedStatementMain {

	static final String URL = "jdbc:mysql://localhost:3306/librarydb";
	static final String USER = "root";
	static final String PASSWORD = "root";

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		PreparedStatementLibrary ps = new PreparedStatementLibrary();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection(URL, USER, PASSWORD);

			int choice;

			do {
				System.out.println("\n===== LIBRARY MANAGEMENT =====");
				System.out.println("1. Insert Book");
				System.out.println("2. Update Book Price");
				System.out.println("3. Delete Book");
				System.out.println("4. Display Books By Category");
				System.out.println("5. Exit");
				System.out.print("Enter Choice: ");

				choice = sc.nextInt();

				switch (choice) {

				case 1:
					ps.insertBook(con, sc);
					break;

				case 2:
					ps.updatePrice(con, sc);
					break;

				case 3:
					ps.deleteBook(con, sc);
					break;

				case 4:
					ps.displayBooks(con, sc);
					break;

				case 5:
					System.out.println("Thank You!");
					break;

				default:
					System.out.println("Invalid Choice!");
				}

			} while (choice != 5);

			con.close();
			sc.close();

		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
