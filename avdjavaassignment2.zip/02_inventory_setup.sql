-- ============================================================
-- PART 2: Product Inventory Management System (CallableStatement)
-- Run this in MySQL BEFORE running ProductInventoryManagement.java
-- ============================================================

CREATE DATABASE IF NOT EXISTS inventory_db;
USE inventory_db;

DROP TABLE IF EXISTS products;

CREATE TABLE products (
    product_id   INT,
    product_name VARCHAR(50),
    category     VARCHAR(30),
    quantity     INT,
    price        DOUBLE
);

INSERT INTO products (product_id, product_name, category, quantity, price) VALUES
(101, 'Wireless Mouse', 'Electronics',  50,  799),
(102, 'Keyboard',       'Electronics',  40,  999),
(103, 'Office Chair',   'Furniture',    15, 4500),
(104, 'Study Table',    'Furniture',    10, 6500),
(105, 'Water Bottle',   'Home',        100,  299),
(106, 'LED Bulb',       'Home',         75,  199),
(107, 'Cricket Bat',    'Sports',       20, 1800),
(108, 'Football',       'Sports',       25, 1200),
(109, 'Backpack',       'Accessories',  35,  999),
(110, 'Travel Bag',     'Accessories',  18, 2200);

-- ---- Stored Procedure: one IN parameter (category) ----
DROP PROCEDURE IF EXISTS GetProductsByCategory;

DELIMITER //
CREATE PROCEDURE GetProductsByCategory(IN p_category VARCHAR(30))
BEGIN
    SELECT product_id, product_name, category, quantity, price
    FROM products
    WHERE category = p_category;
END //
DELIMITER ;

-- Quick test (run in MySQL to verify):
-- CALL GetProductsByCategory('Electronics');
