import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * PART 1: Library Book Management System
 * Uses PreparedStatement for all CRUD-style operations.
 *
 * Operations:
 *   1. Insert Book
 *   2. Update Book Price
 *   3. Delete Book
 *   4. Display Books by Category
 *   5. Display All Books (bonus, helps while testing)
 *   0. Exit
 */
public class LibraryBookManagement {

    // ---- CHANGE THESE 3 LINES AS PER YOUR MySQL SETUP ----
    private static final String URL  = "jdbc:mysql://localhost:3306/library_db";
    private static final String USER = "root";
    private static final String PASS = "root";
    // ------------------------------------------------------

    public static void main(String[] args) {
        // Single connection for the whole session.
        // try-with-resources guarantees it closes even if something fails => no connection leak.
        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             Scanner sc = new Scanner(System.in)) {

            System.out.println("Connected to library_db successfully.\n");

            boolean running = true;
            while (running) {
                printMenu();
                int choice = readInt(sc);

                switch (choice) {
                    case 1: insertBook(con, sc);          break;
                    case 2: updateBookPrice(con, sc);     break;
                    case 3: deleteBook(con, sc);          break;
                    case 4: displayByCategory(con, sc);   break;
                    case 5: displayAll(con);              break;
                    case 0: running = false;
                            System.out.println("Exiting... Bye!");
                            break;
                    default: System.out.println("Invalid choice. Try again.\n");
                }
            }

        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
        // No manual con.close() needed — try-with-resources handles it.
    }

    private static void printMenu() {
        System.out.println("===== Library Book Management =====");
        System.out.println("1. Insert Book");
        System.out.println("2. Update Book Price");
        System.out.println("3. Delete Book");
        System.out.println("4. Display Books by Category");
        System.out.println("5. Display All Books");
        System.out.println("0. Exit");
        System.out.print("Enter choice: ");
    }

    // ---------- 1. INSERT ----------
    private static void insertBook(Connection con, Scanner sc) {
        String sql = "INSERT INTO books (book_id, title, author, category, price) VALUES (?, ?, ?, ?, ?)";

        System.out.print("Enter book_id: ");
        int id = readInt(sc);
        System.out.print("Enter title: ");
        String title = sc.nextLine();
        System.out.print("Enter author: ");
        String author = sc.nextLine();
        System.out.print("Enter category: ");
        String category = sc.nextLine();
        System.out.print("Enter price: ");
        double price = readDouble(sc);

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.setString(2, title);
            ps.setString(3, author);
            ps.setString(4, category);
            ps.setDouble(5, price);

            int rows = ps.executeUpdate();
            System.out.println(rows + " book inserted.\n");
        } catch (SQLException e) {
            System.out.println("Insert failed: " + e.getMessage() + "\n");
        }
    }

    // ---------- 2. UPDATE PRICE ----------
    private static void updateBookPrice(Connection con, Scanner sc) {
        String sql = "UPDATE books SET price = ? WHERE book_id = ?";

        System.out.print("Enter book_id to update: ");
        int id = readInt(sc);
        System.out.print("Enter new price: ");
        double price = readDouble(sc);

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDouble(1, price);
            ps.setInt(2, id);

            int rows = ps.executeUpdate();
            if (rows > 0)
                System.out.println("Price updated for book_id " + id + ".\n");
            else
                System.out.println("No book found with book_id " + id + ".\n");
        } catch (SQLException e) {
            System.out.println("Update failed: " + e.getMessage() + "\n");
        }
    }

    // ---------- 3. DELETE ----------
    private static void deleteBook(Connection con, Scanner sc) {
        String sql = "DELETE FROM books WHERE book_id = ?";

        System.out.print("Enter book_id to delete: ");
        int id = readInt(sc);

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);

            int rows = ps.executeUpdate();
            if (rows > 0)
                System.out.println("Book deleted (book_id " + id + ").\n");
            else
                System.out.println("No book found with book_id " + id + ".\n");
        } catch (SQLException e) {
            System.out.println("Delete failed: " + e.getMessage() + "\n");
        }
    }

    // ---------- 4. DISPLAY BY CATEGORY ----------
    private static void displayByCategory(Connection con, Scanner sc) {
        String sql = "SELECT * FROM books WHERE category = ?";

        System.out.print("Enter category: ");
        String category = sc.nextLine();

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, category);

            try (ResultSet rs = ps.executeQuery()) {
                printHeader();
                boolean found = false;
                while (rs.next()) {
                    found = true;
                    printRow(rs);
                }
                if (!found)
                    System.out.println("No books found in category: " + category);
                System.out.println();
            }
        } catch (SQLException e) {
            System.out.println("Query failed: " + e.getMessage() + "\n");
        }
    }

    // ---------- 5. DISPLAY ALL (bonus) ----------
    private static void displayAll(Connection con) {
        String sql = "SELECT * FROM books ORDER BY book_id";

        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            printHeader();
            while (rs.next()) {
                printRow(rs);
            }
            System.out.println();
        } catch (SQLException e) {
            System.out.println("Query failed: " + e.getMessage() + "\n");
        }
    }

    // ---------- helpers ----------
    private static void printHeader() {
        System.out.printf("%-8s %-28s %-20s %-25s %-8s%n",
                "ID", "Title", "Author", "Category", "Price");
        System.out.println("--------------------------------------------------------------------------------------------");
    }

    private static void printRow(ResultSet rs) throws SQLException {
        System.out.printf("%-8d %-28s %-20s %-25s %-8.2f%n",
                rs.getInt("book_id"),
                rs.getString("title"),
                rs.getString("author"),
                rs.getString("category"),
                rs.getDouble("price"));
    }

    // Safe integer input (avoids crash on bad input)
    private static int readInt(Scanner sc) {
        while (!sc.hasNextInt()) {
            System.out.print("Please enter a valid integer: ");
            sc.next();
        }
        int val = sc.nextInt();
        sc.nextLine(); // consume leftover newline
        return val;
    }

    // Safe double input
    private static double readDouble(Scanner sc) {
        while (!sc.hasNextDouble()) {
            System.out.print("Please enter a valid number: ");
            sc.next();
        }
        double val = sc.nextDouble();
        sc.nextLine(); // consume leftover newline
        return val;
    }
}
