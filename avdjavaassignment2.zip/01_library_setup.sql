-- ============================================================
-- PART 1: Library Book Management System (PreparedStatement)
-- Run this in MySQL BEFORE running LibraryBookManagement.java
-- ============================================================

CREATE DATABASE IF NOT EXISTS library_db;
USE library_db;

DROP TABLE IF EXISTS books;

CREATE TABLE books (
    book_id  INT PRIMARY KEY,
    title    VARCHAR(50),
    author   VARCHAR(50),
    category VARCHAR(30),
    price    DOUBLE
);

INSERT INTO books (book_id, title, author, category, price) VALUES
(101, 'Java Fundamentals',        'James Gosling',     'Programming',             550),
(102, 'Python Basics',            'Guido Rossum',      'Programming',             480),
(103, 'Data Science Handbook',    'Jake VanderPlas',   'Data Science',            750),
(104, 'AI Essentials',            'Stuart Russell',    'Artificial Intelligence', 890),
(105, 'Cloud Computing',          'Rajkumar Buyya',    'Cloud',                   650),
(106, 'Database Systems',         'Elmasri',           'Database',                720),
(107, 'Operating Systems',        'Galvin',            'System Software',         680),
(108, 'Computer Networks',        'Andrew Tanenbaum',  'Networking',              710),
(109, 'Cyber Security Guide',     'William Stallings', 'Security',                830),
(110, 'Machine Learning Concepts','Tom Mitchell',      'Data Science',            920);

-- Quick check
SELECT * FROM books;
