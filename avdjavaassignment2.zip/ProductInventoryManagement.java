import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * PART 2: Product Inventory Management System
 * Uses CallableStatement to call the stored procedure
 * GetProductsByCategory(IN p_category VARCHAR(30)).
 *
 * Flow:
 *   - Accept a category from the user.
 *   - Pass it as an IN parameter to the stored procedure.
 *   - Display all matching product records.
 */
public class ProductInventoryManagement {

    // ---- CHANGE THESE 3 LINES AS PER YOUR MySQL SETUP ----
    private static final String URL  = "jdbc:mysql://localhost:3306/inventory_db";
    private static final String USER = "root";
    private static final String PASS = "root";
    // ------------------------------------------------------

    public static void main(String[] args) {

        // {call ProcName(?)}  -> JDBC escape syntax for stored procedure call
        String call = "{call GetProductsByCategory(?)}";

        System.out.print("Enter product category: ");
        String category;
        try (Scanner sc = new Scanner(System.in)) {
            category = sc.nextLine();
        }

        // try-with-resources closes Connection + CallableStatement automatically => no leak
        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             CallableStatement cs = con.prepareCall(call)) {

            cs.setString(1, category);   // bind the IN parameter

            try (ResultSet rs = cs.executeQuery()) {

                System.out.printf("%n%-12s %-18s %-15s %-10s %-8s%n",
                        "ProductID", "Name", "Category", "Quantity", "Price");
                System.out.println("---------------------------------------------------------------------");

                boolean found = false;
                while (rs.next()) {
                    found = true;
                    System.out.printf("%-12d %-18s %-15s %-10d %-8.2f%n",
                            rs.getInt("product_id"),
                            rs.getString("product_name"),
                            rs.getString("category"),
                            rs.getInt("quantity"),
                            rs.getDouble("price"));
                }

                if (!found)
                    System.out.println("No products found in category: " + category);
            }

        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }
}
