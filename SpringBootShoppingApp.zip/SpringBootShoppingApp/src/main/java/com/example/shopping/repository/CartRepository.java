package com.example.shopping.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.shopping.model.Cart;
import com.example.shopping.model.User;

public interface CartRepository extends JpaRepository<Cart, Integer>
{
	
	List<Cart> findByUser(User user);
	
	void deleteByUser(User user);

}
