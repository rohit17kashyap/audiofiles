package com.example.shopping.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.shopping.model.Order;
import com.example.shopping.model.OrderItem;

public interface OrderItemRepository extends JpaRepository<OrderItem, Integer>
{
	
	List<OrderItem> findByOrder(Order order);

}
