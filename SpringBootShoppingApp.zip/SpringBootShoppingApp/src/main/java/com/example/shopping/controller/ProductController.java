package com.example.shopping.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.shopping.model.Product;
import com.example.shopping.service.ProductService;

@Controller
public class ProductController 
{
	private final ProductService productService;

	public ProductController(ProductService productService) {
		this.productService = productService;
	}
	
	@GetMapping("/products")
	public String viewProducts(Model model) {
		model.addAttribute("products",productService.getAllProducts());
		model.addAttribute("product",new Product());
		return "products";
	}
	
	@PostMapping("/products/add")
	public String addProduct(@ModelAttribute Product product) {
		productService.addProduct(product);
		return "redirect:/product";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
