package com.example.shopping.controller;

import com.example.shopping.model.*;
import com.example.shopping.service.*;
import com.example.shopping.repository.UserRepository;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
public class ShoppingController {

    private final ShoppingService shoppingService;
    private final ProductService productService;
    private final UserRepository userRepository;

    public ShoppingController(ShoppingService shoppingService,
                              ProductService productService,
                              UserRepository userRepository) {
        this.shoppingService = shoppingService;
        this.productService = productService;
        this.userRepository = userRepository;
    }

    // Current logged in user nikalo
    private User getCurrentUser(Authentication auth) {
        return userRepository.findByUsername(auth.getName());
    }

    // Cart dikhao
    @GetMapping("/cart")
    public String viewCart(Model model, Authentication auth) {
        User user = getCurrentUser(auth);
        List<Cart> cartItems = shoppingService.getCartItems(user);
        double total = shoppingService.calculateTotal(cartItems);
        model.addAttribute("cartItems", cartItems);
        model.addAttribute("total", total);
        return "cart";  // cart.html
    }

    // Cart mein add karo
    @PostMapping("/cart/add")
    public String addToCart(@RequestParam int productId,
                            @RequestParam int quantity,
                            Authentication auth) {
        User user = getCurrentUser(auth);
        shoppingService.addToCart(user, productId, quantity);
        return "redirect:/cart";
    }

    // Cart se remove karo
    @GetMapping("/cart/remove/{id}")
    public String removeFromCart(@PathVariable int id) {
        shoppingService.removeFromCart(id);
        return "redirect:/cart";
    }

    // Order place karo
    @PostMapping("/order/place")
    public String placeOrder(Authentication auth) {
        User user = getCurrentUser(auth);
        shoppingService.placeOrder(user);
        return "redirect:/orders";
    }

    // Orders dikhao
    @GetMapping("/orders")
    public String viewOrders(Model model, Authentication auth) {
        User user = getCurrentUser(auth);
        List<Order> orders = shoppingService.getOrders(user);
        model.addAttribute("orders", orders);
        return "orders";  // orders.html
    }
}