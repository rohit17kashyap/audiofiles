package com.example.shopping.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.shopping.model.Order;
import com.example.shopping.model.User;

public interface OrderRepository extends JpaRepository<Order, Integer> {
	List<Order> findByUser(User user);

}
