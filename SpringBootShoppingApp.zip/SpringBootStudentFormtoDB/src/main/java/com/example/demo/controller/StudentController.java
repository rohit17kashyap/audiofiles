package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepository;

@Controller
public class StudentController {

	private final StudentRepository studentRepository;

	public StudentController(StudentRepository studentRepository) {
		this.studentRepository = studentRepository;
	}

	@GetMapping("/addStudent")
	public String addStudents(Model model) {
		model.addAttribute("student", new Student());
		return "addStudent";

	}

	@PostMapping("/saveStudent")
	public String saveStudent(@ModelAttribute Student student) {
		studentRepository.save(student);
		return "redirect:/viewStudents";
	}

	@GetMapping("/viewStudents")
	public String viewStudents(Model model) {
		model.addAttribute("students", studentRepository.findAll());
		return "viewStudents";
	}

	@GetMapping("/deleteStudent/{id}")
	public String deleteStudent(@PathVariable int id) {
		studentRepository.deleteById(id);
		return "redirect:/viewStudents";
	}

}
