package jdbcassigment1;

import java.util.Scanner;

public class JdbcMain {

	public static void main(String[] args) throws Exception {
		
		Scanner scan = new Scanner(System.in);
		JdbcManagement jdbc = new JdbcManagement();
		while(true)
		{
		    System.out.println("1.Insert");
		    System.out.println("2.Update");
		    System.out.println("3.Delete");
		    System.out.println("4.Display");
		    System.out.println("5.Search");
		    System.out.println("6.Display Based on Condition");
		    System.out.println("7.Exit");

		    int choice=scan.nextInt();

		    switch(choice)
		    {
		    case 1:jdbc.insertInTable();break;
		    case 2:jdbc.upadteInTable();break;
		    case 3:jdbc.deleteInTable();break;
		    case 4:jdbc.dispalyTable();break;
		    case 5:jdbc.searchInTable();break;
		    case 6: jdbc.displayByCondition(); break;
		    case 7:System.exit(0);
		    default:System.out.println("Invalid choice!!!");
		    }
		}

	}

}
