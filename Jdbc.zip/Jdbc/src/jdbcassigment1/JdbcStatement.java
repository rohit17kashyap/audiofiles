package jdbcassigment1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JdbcStatement {
	public int databaseUpadte(String query) {
		int n = 0;
		try {
			// 1. Load Driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			// 2. Create Connection
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "root");

			// 3. Create Statement
			Statement stmt = con.createStatement();

			// 4. Execute Query for insert / update / delete
			n = stmt.executeUpdate(query);

			stmt.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return n;
	}

	public ResultSet databaseExecute(String query) throws Exception {
		ResultSet rs = null;
		try {
			// 1. Load Driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			// 2. Create Connection
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "root");

			// 3. Create Statement
			Statement stmt = con.createStatement();

			// 4. Execute Query for display(select)
			rs = stmt.executeQuery(query);

		} catch (Exception e) {
			e.printStackTrace();
		} 
		return rs;

	}

}
