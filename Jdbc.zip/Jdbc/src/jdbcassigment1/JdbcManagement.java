package jdbcassigment1;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Scanner;

public class JdbcManagement {

	Scanner scan = new Scanner(System.in);
	JdbcStatement jdbc = new JdbcStatement();

	public void insertInTable() {
		System.out.println("Enter Student Id");
		int sid = scan.nextInt();
		scan.nextLine();
		System.out.println("Enter Student Name");
		String sname = scan.nextLine();
		System.out.println("Enter Student's Course");
		String course = scan.nextLine();
		System.out.println("Enter Student's marks");
		int marks = scan.nextInt();
		scan.nextLine();
		System.out.println("Enter Student's city");
		String city = scan.nextLine();

		String sql = "insert into student values(" + sid + ",'" + sname + "','" + course + "'," + marks + ",'" + city
				+ "')";

		int rows = jdbc.databaseUpadte(sql);

		if (rows > 0)
			System.out.println("Insert Successfully!");
		else
			System.out.println("Insert not going to happen!!");

	}

	public void upadteInTable() {
		System.out.println("Enter Student Id you want to update");
		int sid = scan.nextInt();
		scan.nextLine();
		System.out.println("Enter upadted Student Name");
		String sname = scan.nextLine();
		System.out.println("Enter upadted Student's Course");
		String course = scan.nextLine();
		System.out.println("Enter upadted Student's marks");
		int marks = scan.nextInt();
		scan.nextLine();
		System.out.println("Enter upadted Student's city");
		String city = scan.nextLine();

		String sql = "UPDATE student SET " + "student_name='" + sname + "', " + "course='" + course + "', " + "marks="
				+ marks + ", " + "city='" + city + "' " + "WHERE student_id=" + sid;

		int rows = jdbc.databaseUpadte(sql);

		if (rows > 0)
			System.out.println("Record Updated Successfully!");
		else
			System.out.println("Student ID Not Found!");

	}

	public void deleteInTable() {
		System.out.println("Enter Student Id you want to delete");
		int sid = scan.nextInt();

		String sql = "DELETE FROM student WHERE student_id=" + sid;

		int rows = jdbc.databaseUpadte(sql);

		if (rows > 0)
			System.out.println("Record Deleted Successfully!");
		else
			System.out.println("Student ID Not Found!");

	}

	public void dispalyTable() throws Exception {

		String sql = "Select * from student";

		ResultSet rs = jdbc.databaseExecute(sql);
		printResultSet(rs);

	}

	public void searchInTable() throws Exception {

		System.out.println("Enter Student Id you want to search");
		int sid = scan.nextInt();

		String sql = "Select * from student where student_id=" + sid;

		ResultSet rs = jdbc.databaseExecute(sql);
		printResultSet(rs);

	}

	public void displayByCondition() throws Exception {
		System.out.println("Enter condition (e.g. marks>80, city='Pune'):");
		//scan.nextLine();
		String cond = scan.nextLine();

		String sql = "SELECT * FROM student WHERE " + cond;
		ResultSet rs = jdbc.databaseExecute(sql);
		printResultSet(rs);
	}

	private void printResultSet(ResultSet rs) throws Exception {
		ResultSetMetaData metaData = rs.getMetaData();

		int columnCount = metaData.getColumnCount();

		// Print column names
		for (int i = 1; i <= columnCount; i++) {
			System.out.printf("%-20s", metaData.getColumnName(i));
		}
		System.out.println();

		// Print rows
		while (rs.next()) {
			for (int i = 1; i <= columnCount; i++) {
				System.out.printf("%-20s", rs.getString(i));
			}
			System.out.println();
		}
	}

}
