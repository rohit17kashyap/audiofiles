package jdbcexample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcStatementExample 
{

	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
	
		//select
		
		System.out.println("select emp");
		
		//loading the drivers
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		//getting connection
		
	Connection con =	DriverManager.getConnection("jdbc:mysql://localhost:3306/rohit_cdac","root","root");
		
	// create statement
	
		     Statement smt ;
		     smt =  con.createStatement();
		     
    // create query
		     
		     String q;
		     q= "select * from emp";
		     
    //execute the query
		     
		  ResultSet rs=smt.executeQuery(q);
		  
		  
    //iterate the result
		  
		    while(rs.next())
		    {
		    	
		    	System.out.println(rs.getInt(1)+"  "+ rs.getString(2)+"  "+ rs.getString(3));
		    	
		    }
		          
		//close the connection
		    
		    
		//update
		    
		  System.out.println("update emp");  
		    smt =  con.createStatement();
		    
		    q="update emp set sal = sal+100 where empno = 7499";	
		    
		  int n =smt.executeUpdate(q);
		    
		    
		  System.out.println("recored updated = "+ n);
		  
		  
		  rs.close();
		  con.close();
		    
	}
	
}
