package com.cdac.OnlineShoppingSystem;

import org.springframework.stereotype.Component;

@Component
public class Product {

	private int productId = 201;
	private String productName = "Wireless Mouse";
	private double price = 899;
	
	public void displayProduct()
	{
		System.out.println("Product Details");
		System.out.println("---------------");
		System.out.println("Product Id    :"+productId);
		System.out.println("Product Name  :"+productName);
		System.out.println("Price         :"+price);
		
	}

}
