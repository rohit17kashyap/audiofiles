package com.cdac.OnlineShoppingSystem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ShoppingCart {
	
	private int cartId = 5001;
	private String customerName = "Rahul Sharma";
	
	@Autowired
	private Product product;
	
	public void displayShopping()
	{
		System.out.println("Cart Id       :"+cartId);
		System.out.println("Customer Name :"+customerName);
		System.out.println();
		product.displayProduct();
		
	}

}
