package com.cdac.OnlineShoppingSystem;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		ShoppingCart s = context.getBean(ShoppingCart.class);
		s.displayShopping();
	}
}
