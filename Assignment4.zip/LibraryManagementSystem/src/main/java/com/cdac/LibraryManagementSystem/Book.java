package com.cdac.LibraryManagementSystem;

public class Book {

	private int bookId;
	private String title;
	private String author;
	private double price;

	public Book(int bookId, String title, String author, double price) {
		this.bookId = bookId;
		this.title = title;
		this.author = author;
		this.price = price;
	}

	public Book() {
	}
	
	public void displayBook()
	{
		System.out.println("Book Details");
		System.out.println("------------");
		System.out.println("BookId : "+bookId);
		System.out.println("Title : "+title);
		System.out.println("Author : "+author);
		System.out.println("Price : "+price);
	}
	
	

}
