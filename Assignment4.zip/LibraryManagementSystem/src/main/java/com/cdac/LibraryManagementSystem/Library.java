package com.cdac.LibraryManagementSystem;

public class Library {

	private String libraryName;
	private String location;
	private Book book;

	public Library(String libraryName, String location, Book book) {
		this.libraryName = libraryName;
		this.location = location;
		this.book = book;
	}
	
	public void displayLibrary()
	{
		System.out.println("Library Name : "+libraryName);
		System.out.println("Location     : "+location);
		System.out.println();
		book.displayBook();
	}

}
