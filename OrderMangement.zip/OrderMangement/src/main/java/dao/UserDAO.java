package dao;

import java.sql.*;

import util.DBUtil;

public class UserDAO {

	public boolean validateUser(String username, String password) {

		boolean status = false;

		try {
			Connection con = DBUtil.getConnection();

			PreparedStatement ps = con.prepareStatement("select * from users where username=? and password=?");

			ps.setString(1, username);
			ps.setString(2, password);

			ResultSet rs = ps.executeQuery();

			status = rs.next();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return status;
	}
}