package dao;

import java.sql.*;

import model.CartItem;
import util.DBUtil;

public class OrderDAO {

	public void saveOrder(String username, CartItem item) {

		try {

			Connection con = DBUtil.getConnection();

			PreparedStatement ps = con
					.prepareStatement("insert into orders(username,food_name,quantity,total_amount) values(?,?,?,?)");

			ps.setString(1, username);
			ps.setString(2, item.getFoodName());
			ps.setInt(3, item.getQuantity());
			ps.setDouble(4, item.getPrice() * item.getQuantity());

			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}