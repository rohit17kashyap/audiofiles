package model;

public class CartItem {

	private String foodName;
	private int quantity;
	private double price;

	public CartItem() {
	}

	public CartItem(String foodName, int quantity, double price) {
		this.foodName = foodName;
		this.quantity = quantity;
		this.price = price;
	}

	public String getFoodName() {
		return foodName;
	}

	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
}