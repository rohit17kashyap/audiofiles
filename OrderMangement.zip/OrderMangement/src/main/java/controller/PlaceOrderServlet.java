package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.*;
import javax.servlet.http.*;

import dao.OrderDAO;
import model.CartItem;

public class PlaceOrderServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();

		String username = (String) session.getAttribute("username");

		List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");

		OrderDAO dao = new OrderDAO();

		for (CartItem item : cart) {

			dao.saveOrder(username, item);
		}

		session.removeAttribute("cart");

		response.sendRedirect("success.jsp");
	}
}