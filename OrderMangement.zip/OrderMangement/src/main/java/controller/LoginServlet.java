package controller;

import java.io.IOException;

import javax.servlet.*;
import javax.servlet.http.*;

import dao.UserDAO;

public class LoginServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String username = request.getParameter("username");
		String password = request.getParameter("password");

		UserDAO dao = new UserDAO();

		if (dao.validateUser(username, password)) {

			HttpSession session = request.getSession();
			session.setAttribute("username", username);

			response.sendRedirect("menu.jsp");

		} else {

			response.getWriter().println("Invalid Login");
		}
	}
}