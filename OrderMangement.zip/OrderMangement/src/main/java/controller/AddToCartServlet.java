package controller;

import java.io.IOException;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

import model.CartItem;

public class AddToCartServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String food = request.getParameter("foodName");
		int qty = Integer.parseInt(request.getParameter("quantity"));

		double price = 0;

		if (food.equals("Pizza"))
			price = 250;

		else if (food.equals("Burger"))
			price = 120;

		else if (food.equals("Sandwich"))
			price = 100;

		HttpSession session = request.getSession();

		List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");

		if (cart == null) {
			cart = new ArrayList<CartItem>();
		}

		cart.add(new CartItem(food, qty, price));

		session.setAttribute("cart", cart);

		response.sendRedirect("cart.jsp");
	}
}