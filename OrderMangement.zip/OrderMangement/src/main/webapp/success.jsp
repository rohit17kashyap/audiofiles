<h2>Order Placed Successfully</h2>

<a href="menu.jsp">Back To Menu</a>