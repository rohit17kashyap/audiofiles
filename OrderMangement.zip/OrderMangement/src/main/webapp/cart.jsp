<%@ page import="java.util.*,model.CartItem"%>

<h2>Cart Items</h2>

<%
List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");

double total = 0;

if (cart != null) {

	for (CartItem c : cart) {
%>

Food :
<%=c.getFoodName()%>
Qty :
<%=c.getQuantity()%>
Price :
<%=c.getPrice()%>

<br>

<%
total += c.getPrice() * c.getQuantity();
}
}
%>

<h3>
	Total =
	<%=total%></h3>

<form action="PlaceOrderServlet" method="post">
	<input type="submit" value="Place Order">
</form>