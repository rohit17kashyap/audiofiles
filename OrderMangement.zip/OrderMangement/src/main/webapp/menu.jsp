<%@ page session="true"%>

<h2>
	Welcome :
	<%=session.getAttribute("username")%></h2>

<form action="AddToCartServlet" method="post">

	Food : <select name="foodName">
		<option value="Pizza">Pizza</option>
		<option value="Burger">Burger</option>
		<option value="Sandwich">Sandwich</option>
	</select> Quantity : <input type="number" name="quantity"> <input
		type="submit" value="Add To Cart">

</form>

<a href="cart.jsp">View Cart</a>