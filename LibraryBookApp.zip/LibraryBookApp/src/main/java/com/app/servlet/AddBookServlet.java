package com.app.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.app.dao.BookDAO;
import com.app.model.Book;

public class AddBookServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            response.sendRedirect("index.html");
            return;
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            int bid = Integer.parseInt(request.getParameter("bid"));
            String bname = request.getParameter("bname");
            String author = request.getParameter("author");
            double price = Double.parseDouble(request.getParameter("price"));

            Book b = new Book(bid, bname, author, price);
            BookDAO dao = new BookDAO();

            if (dao.addBook(b)) {
                out.println("<h3>Book Added Successfully!</h3>");
            } else {
                out.println("<h3>Failed to Add Book! (Book ID duplicate to nahi?)</h3>");
            }
            out.println("<a href='home.jsp'>Home</a> | <a href='viewbooks'>View All Books</a>");

        } catch (NumberFormatException e) {
            out.println("<h3>Invalid Book ID or Price!</h3>");
            out.println("<a href='addbook.jsp'>Try Again</a>");
        }
    }
}
