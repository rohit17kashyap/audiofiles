package com.app.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.app.dao.BookDAO;
import com.app.model.Book;

public class UpdateBookServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            response.sendRedirect("index.html");
            return;
        }

        try {
            int bid = Integer.parseInt(request.getParameter("bid"));
            BookDAO dao = new BookDAO();
            Book b = dao.getBookById(bid);

            if (b == null) {
                response.setContentType("text/html");
                PrintWriter out = response.getWriter();
                out.println("<h3>Book not found!</h3>");
                out.println("<a href='viewbooks'>Back</a>");
                return;
            }

            request.setAttribute("book", b);
            RequestDispatcher rd = request.getRequestDispatcher("updatebook.jsp");
            rd.forward(request, response);

        } catch (NumberFormatException e) {
            response.sendRedirect("viewbooks");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            response.sendRedirect("index.html");
            return;
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            int bid = Integer.parseInt(request.getParameter("bid"));
            String bname = request.getParameter("bname");
            String author = request.getParameter("author");
            double price = Double.parseDouble(request.getParameter("price"));

            Book b = new Book(bid, bname, author, price);
            BookDAO dao = new BookDAO();

            if (dao.updateBook(b)) {
                response.sendRedirect("viewbooks");
            } else {
                out.println("<h3>Update Failed!</h3>");
                out.println("<a href='viewbooks'>Back</a>");
            }

        } catch (NumberFormatException e) {
            out.println("<h3>Invalid input!</h3>");
            out.println("<a href='viewbooks'>Back</a>");
        }
    }
}
