<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.app.model.Book"%>
<%
    if (session.getAttribute("username") == null) {
        response.sendRedirect("index.html");
        return;
    }
    Book b = (Book) request.getAttribute("book");
    if (b == null) {
        response.sendRedirect("viewbooks");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Update Book</title>
</head>
<body>
    <h2>Update Book</h2>
    <form action="updatebook" method="post">
        Book ID: <input type="number" name="bid" value="<%= b.getBid() %>" readonly><br><br>
        Book Name: <input type="text" name="bname" value="<%= b.getBname() %>" required><br><br>
        Author: <input type="text" name="author" value="<%= b.getAuthor() %>" required><br><br>
        Price: <input type="number" step="0.01" name="price" value="<%= b.getPrice() %>" required><br><br>
        <input type="submit" value="Update Book">
    </form>
    <p><a href="viewbooks">Back to Book List</a></p>
</body>
</html>
