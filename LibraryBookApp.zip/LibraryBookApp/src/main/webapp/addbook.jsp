<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    if (session.getAttribute("username") == null) {
        response.sendRedirect("index.html");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Add Book</title>
</head>
<body>
    <h2>Add New Book</h2>
    <form action="addbook" method="post">
        Book ID: <input type="number" name="bid" required><br><br>
        Book Name: <input type="text" name="bname" required><br><br>
        Author: <input type="text" name="author" required><br><br>
        Price: <input type="number" step="0.01" name="price" required><br><br>
        <input type="submit" value="Add Book">
    </form>
    <p><a href="home.jsp">Back to Home</a></p>
</body>
</html>
