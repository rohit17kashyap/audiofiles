<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    if (session.getAttribute("username") == null) {
        response.sendRedirect("index.html");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Library Home</title>
</head>
<body>
    <h2>Welcome, <%= session.getAttribute("username") %>!</h2>
    <h3>Library Book Management</h3>
    <ul>
        <li><a href="addbook.jsp">Add New Book</a></li>
        <li><a href="viewbooks">View All Books</a></li>
        <li><a href="logout">Logout</a></li>
    </ul>
</body>
</html>
