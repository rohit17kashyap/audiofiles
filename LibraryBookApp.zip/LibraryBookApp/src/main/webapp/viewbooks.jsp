<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.ArrayList, com.app.model.Book"%>
<%
    if (session.getAttribute("username") == null) {
        response.sendRedirect("index.html");
        return;
    }
    ArrayList<Book> books = (ArrayList<Book>) request.getAttribute("books");
%>
<!DOCTYPE html>
<html>
<head>
    <title>All Books</title>
</head>
<body>
    <h2>All Books</h2>
    <table border="1">
        <tr>
            <th>Book ID</th>
            <th>Book Name</th>
            <th>Author</th>
            <th>Price</th>
            <th>Action</th>
        </tr>
        <%
            if (books != null && !books.isEmpty()) {
                for (Book b : books) {
        %>
        <tr>
            <td><%= b.getBid() %></td>
            <td><%= b.getBname() %></td>
            <td><%= b.getAuthor() %></td>
            <td><%= b.getPrice() %></td>
            <td><a href="updatebook?bid=<%= b.getBid() %>">Edit</a></td>
        </tr>
        <%
                }
            } else {
        %>
        <tr><td colspan="5">No books found</td></tr>
        <%
            }
        %>
    </table>
    <p><a href="home.jsp">Back to Home</a> | <a href="logout">Logout</a></p>
</body>
</html>
