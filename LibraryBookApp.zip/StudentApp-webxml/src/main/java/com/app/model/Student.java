package com.app.model;

public class Student {
    private int rollno;
    private String name;
    private String course;
    private String password;

    public Student() {
    }

    public Student(int rollno, String name, String course, String password) {
        this.rollno = rollno;
        this.name = name;
        this.course = course;
        this.password = password;
    }

    public int getRollno() {
        return rollno;
    }

    public void setRollno(int rollno) {
        this.rollno = rollno;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
