package com.app.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.app.model.Student;

public class WelcomeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("student") == null) {
            response.sendRedirect("index.html");
            return;
        }

        Student s = (Student) session.getAttribute("student");

        out.println("<h2>Welcome, " + s.getName() + "!</h2>");
        out.println("<p>Roll No: " + s.getRollno() + "</p>");
        out.println("<p>Name: " + s.getName() + "</p>");
        out.println("<p>Course: " + s.getCourse() + "</p>");
        out.println("<a href='logout'>Logout</a>");
    }
}
