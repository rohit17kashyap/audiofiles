package com.app.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.app.dao.StudentDAO;
import com.app.model.Student;

public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            int rollno = Integer.parseInt(request.getParameter("rollno"));
            String password = request.getParameter("password");

            StudentDAO dao = new StudentDAO();
            Student s = dao.login(rollno, password);

            if (s != null) {
                HttpSession session = request.getSession();
                session.setAttribute("student", s);
                response.sendRedirect("welcome");
            } else {
                out.println("<h3>Invalid Roll No or Password!</h3>");
                out.println("<a href='index.html'>Try Again</a>");
            }

        } catch (NumberFormatException e) {
            out.println("<h3>Invalid Roll No!</h3>");
            out.println("<a href='index.html'>Try Again</a>");
        }
    }
}
