package com.app.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.app.dao.StudentDAO;
import com.app.model.Student;

public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            int rollno = Integer.parseInt(request.getParameter("rollno"));
            String name = request.getParameter("name");
            String course = request.getParameter("course");
            String password = request.getParameter("password");

            StudentDAO dao = new StudentDAO();

            if (dao.exists(rollno)) {
                out.println("<h3>Roll No " + rollno + " already registered!</h3>");
                out.println("<a href='register.html'>Try Again</a>");
                return;
            }

            Student s = new Student(rollno, name, course, password);

            if (dao.register(s)) {
                out.println("<h3>Registration Successful!</h3>");
                out.println("<a href='index.html'>Go to Login</a>");
            } else {
                out.println("<h3>Registration Failed!</h3>");
                out.println("<a href='register.html'>Try Again</a>");
            }

        } catch (NumberFormatException e) {
            out.println("<h3>Invalid Roll No!</h3>");
            out.println("<a href='register.html'>Try Again</a>");
        }
    }
}
