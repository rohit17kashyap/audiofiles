﻿using System;
using System.Collections.Generic;
using System.Linq;

class Task1_StudentCourse
{
    class Student
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; } = "";
    }

    class Course
    {
        public int CourseId { get; set; }
        public string CourseName { get; set; } = "";
        public int StudentId { get; set; }
    }

    static void Main()
    {
        // Create lists
        List<Student> students = new List<Student>
        {
            new Student { StudentId = 1, StudentName = "Alice" },
            new Student { StudentId = 2, StudentName = "Bob" },
            new Student { StudentId = 3, StudentName = "Charlie" }
        };

        List<Course> courses = new List<Course>
        {
            new Course { CourseId = 101, CourseName = "Mathematics", StudentId = 1 },
            new Course { CourseId = 102, CourseName = "Physics", StudentId = 1 },
            new Course { CourseId = 103, CourseName = "Chemistry", StudentId = 2 },
            new Course { CourseId = 104, CourseName = "Biology", StudentId = 3 }
        };

        // LINQ Join Query
        var studentCourses = from student in students
                             join course in courses
                             on student.StudentId equals course.StudentId
                             select new
                             {
                                 StudentName = student.StudentName,
                                 CourseName = course.CourseName
                             };

        Console.WriteLine("Student and their Courses:");
        foreach (var item in studentCourses)
        {
            Console.WriteLine($"Student: {item.StudentName}, Course: {item.CourseName}");
        }
    }
}