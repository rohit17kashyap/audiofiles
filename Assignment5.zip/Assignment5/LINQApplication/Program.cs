﻿using System;
using System.Collections.Generic;
using System.Linq;

class Customer
{
    public int CustomerId { get; set; }
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string City { get; set; } = "";
}

class Product
{
    public int ProductId { get; set; }
    public string ProductName { get; set; }
    public double UnitPrice { get; set; }
}

class Order
{
    public int OrderId { get; set; }
    public int CustomerId { get; set; }
    public string ShipCity { get; set; } = "";
}

class OrderDetail
{
    public int OrderDetailId { get; set; }
    public int OrderId { get; set; }
    public int ProductId { get; set; }
    public int Quantity { get; set; }
}

class Program
{
    static void Main()
    {
        // Customer List
        List<Customer> customers = new List<Customer>()
        {
            new Customer { CustomerId = 1, FirstName = "Rohit", LastName = "Kashyap", City = "Delhi" },
            new Customer { CustomerId = 2, FirstName = "Aman", LastName = "Sharma", City = "Bangalore" },
            new Customer { CustomerId = 3, FirstName = "Priya", LastName = "Verma", City = "Mumbai" }
        };

        // Product List
        List<Product> products = new List<Product>()
        {
            new Product { ProductId = 1, ProductName = "Laptop", UnitPrice = 50000 },
            new Product { ProductId = 2, ProductName = "Mouse", UnitPrice = 800 },
            new Product { ProductId = 3, ProductName = "Keyboard", UnitPrice = 1500 }
        };

        // Order List
        List<Order> orders = new List<Order>()
        {
            new Order { OrderId = 101, CustomerId = 2, ShipCity = "Bangalore" },
            new Order { OrderId = 102, CustomerId = 1, ShipCity = "Delhi" },
            new Order { OrderId = 103, CustomerId = 2, ShipCity = "Bangalore" }
        };

        // OrderDetail List
        List<OrderDetail> orderDetails = new List<OrderDetail>()
        {
            new OrderDetail { OrderDetailId = 1, OrderId = 101, ProductId = 1, Quantity = 1 },
            new OrderDetail { OrderDetailId = 2, OrderId = 102, ProductId = 2, Quantity = 2 }
        };

        // a. Customers in alphabetical order by Last Name
        var customerResult = customers.OrderBy(c => c.LastName);

        Console.WriteLine("Customers Sorted by Last Name:");

        foreach (var c in customerResult)
        {
            Console.WriteLine(c.FirstName + " " + c.LastName);
        }

        Console.WriteLine();

        // b. Products by Unit Price (Highest to Lowest)
        var productResult = products.OrderByDescending(p => p.UnitPrice);

        Console.WriteLine("Products Sorted by Price:");

        foreach (var p in productResult)
        {
            Console.WriteLine(p.ProductName + " - " + p.UnitPrice);
        }

        Console.WriteLine();

        // c. Orders shipped to Bangalore customers
        var bangaloreOrders = orders.Where(o => o.ShipCity == "Bangalore");

        Console.WriteLine("Orders Shipped to Bangalore:");

        foreach (var o in bangaloreOrders)
        {
            Console.WriteLine("Order ID: " + o.OrderId);
        }
    }
}